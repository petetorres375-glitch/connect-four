from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# Game State: 6 rows, 7 columns
board = [[None for _ in range(7)] for _ in range(6)]

def check_winner(board, player):
    # Horizontal check
    for r in range(6):
        for c in range(4):
            if all(board[r][c+i] == player for i in range(4)):
                return True
    # Vertical check
    for r in range(3):
        for c in range(7):
            if all(board[r+i][c] == player for i in range(4)):
                return True
    # Diagonal check (positive slope)
    for r in range(3, 6):
        for c in range(4):
            if all(board[r-i][c+i] == player for i in range(4)):
                return True
    # Diagonal check (negative slope)
    for r in range(3):
        for c in range(4):
            if all(board[r+i][c+i] == player for i in range(4)):
                return True
    return False

def get_ai_move():
    # Find all columns that aren't full
    valid_cols = [c for c in range(7) if board[0][c] is None]
    if not valid_cols:
        return None
    
    # Pick a random valid column
    col = random.choice(valid_cols)
    for r in range(5, -1, -1):
        if board[r][col] is None:
            return {"row": r, "col": col}
    return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/move', methods=['POST'])
def move():
    global board
    data = request.json
    player_col = data.get('column')
    
    # 1. PLAYER MOVE (RED)
    player_row = -1
    for r in range(5, -1, -1):
        if board[r][player_col] is None:
            board[r][player_col] = "Red"
            player_row = r
            break
            
    if player_row == -1:
        return jsonify({"error": "Column full"}), 400

    # Check if player won
    winner = "Red" if check_winner(board, "Red") else None
    ai_move_data = None

    # 2. AI MOVE (YELLOW) - Only happens if player didn't win yet
    if not winner:
        ai_pos = get_ai_move()
        if ai_pos:
            board[ai_pos['row']][ai_pos['col']] = "Yellow"
            ai_move_data = {
                "row": ai_pos['row'],
                "col": ai_pos['col'],
                "player": "Yellow",
                "winner": "Yellow" if check_winner(board, "Yellow") else None
            }

    # If AI wins, set the global winner
    if ai_move_data and ai_move_data['winner']:
        winner = "Yellow"

    return jsonify({
        "player_move": {
            "row": player_row, 
            "col": player_col, 
            "player": "Red", 
            "winner": "Red" if winner == "Red" else None
        },
        "ai_move": ai_move_data
    })

@app.route('/reset', methods=['POST'])
def reset():
    global board
    board = [[None for _ in range(7)] for _ in range(6)]
    return jsonify({"status": "success"})

if __name__ == '__main__':
    # Listen on your Lenovo's IP (192.168.1.13)
    app.run(debug=True, host='0.0.0.0', port=5000)
