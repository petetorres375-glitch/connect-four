import random
import copy

class ConnectFour:
    def __init__(self):
        self.board = [[None for _ in range(7)] for _ in range(6)]
        self.current_player = "Red"
        self.winner = None

    def drop_piece(self, col):
        """This is the method Flask is looking for!"""
        if self.winner or col < 0 or col > 6:
            return None

        for row in reversed(range(6)):
            if self.board[row][col] is None:
                self.board[row][col] = self.current_player
                
                if self.check_winner(row, col):
                    self.winner = self.current_player
                
                last_player = self.current_player
                self.current_player = "Yellow" if self.current_player == "Red" else "Red"
                return {"row": row, "col": col, "player": last_player, "winner": self.winner}
        return None

    def check_winner(self, r, c):
        player = self.board[r][c]
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for dr, dc in directions:
            count = 1
            for delta in [1, -1]:
                nr, nc = r + dr * delta, c + dc * delta
                while 0 <= nr < 6 and 0 <= nc < 7 and self.board[nr][nc] == player:
                    count += 1
                    nr += dr * delta
                    nc += dc * delta
            if count >= 4: return True
        return False

    def get_ai_move(self, level):
        valid_columns = [c for c in range(7) if self.board[0][c] is None]
        if not valid_columns: return None
        
        if level == "easy":
            return random.choice(valid_columns)
        
        # Medium and Hard logic here...
        return random.choice(valid_columns)

    def reset(self):
        self.__init__()
