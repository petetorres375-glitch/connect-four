// 1. Audio Assets
const dropSound = new Audio('/static/drop.mp3');
const winSound = new Audio('/static/yippee.mp3');

const boardElement = document.getElementById('board');
const statusText = document.getElementById('status');
const gameModeSelect = document.getElementById('gameMode');
const difficultySelect = document.getElementById('difficulty');

let gameOver = false;

function createBoard() {
    boardElement.innerHTML = '';
    gameOver = false;
    statusText.innerText = "Red's Turn";
    statusText.style.color = "white";
    statusText.classList.remove('winner-text');

    for (let r = 0; r < 6; r++) {
        for (let c = 0; c < 7; c++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.dataset.row = r;
            cell.dataset.col = c;
            cell.addEventListener('click', () => handleMove(c));
            boardElement.appendChild(cell);
        }
    }
}

async function handleMove(colIndex) {
    if (gameOver) return;

    const mode = gameModeSelect.value;
    const difficulty = difficultySelect.value;

    // This URL (/move) MUST match the Python @app.route
    const response = await fetch('/move', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            column: colIndex, 
            mode: mode, 
            difficulty: difficulty 
        })
    });

    if (!response.ok) {
        console.error("Server error: 404 Move not found. Check app.py routes!");
        return;
    }

    const data = await response.json();

    // Human Move
    updateCell(data.player_move.row, data.player_move.col, data.player_move.player);
    
    if (data.player_move.winner) {
        endGame(data.player_move.winner);
        return;
    }

    // AI Move logic
    if (data.ai_move) {
        statusText.innerText = "AI is thinking...";
        setTimeout(() => {
            updateCell(data.ai_move.row, data.ai_move.col, data.ai_move.player);
            if (data.ai_move.winner) {
                endGame(data.ai_move.winner);
            } else {
                statusText.innerText = "Red's Turn";
            }
        }, 600); 
    }
}

function updateCell(row, col, player) {
    const index = row * 7 + col;
    const cell = boardElement.children[index];
    
    dropSound.currentTime = 0; 
    dropSound.play().catch(e => console.log("Click the board to enable sound!"));
    
    cell.classList.add(player); 
    const fallDuration = 0.1 * (row + 1); 
    cell.style.animation = `dropAnim ${fallDuration}s ease-in`;
}

function endGame(winner) {
    gameOver = true;
    setTimeout(() => {
        winSound.currentTime = 0; 
        winSound.play().catch(e => console.error("Sound blocked by browser.", e));
    }, 350); 

    statusText.innerText = `${winner} Wins! 🎉`;
    statusText.style.color = winner === "Red" ? "#e74c3c" : "#f1c40f";
    statusText.classList.add('winner-text');
}

async function resetGame() {
    await fetch('/reset', { method: 'POST' });
    createBoard();
}

createBoard();
